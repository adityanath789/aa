a=int(input("Enter a number: "))
if a%2 !=0:
  print(a,"is an odd number.")
else:
    print(a,"is an even number.")